
package ds_project;



import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        PharmacySystem p = new PharmacySystem("Pharmacy System");
        System.out.println("*** Welcome To " + p.getName() + " ***");
        int option = 0;

        do {
            try {

                System.out.println("---------------------------------------------");
                System.out.println(
                        "1. Add a new product to the inventory\n"//linked list
                        + "2. Search for a product by ID\n"//linked list
                        + "3. Add a new prescription\n"//queue
                        + "4. Display information about a specific prescription\n"//queue
                        + "5. Show the next prescription in the queue\n"//queue
                        + "6. Check out and process the next prescription\n"//queue
                        + "7. Display all products in stock\n"//linked list
                        + "8. Exit the system");
                System.out.print("---------------------------------------------\n"
                        + "Your selection >>> ");

                option = input.nextInt();

                switch (option) {
                    case 1:
                        System.out.println("Adding a new product...");
                        p.addProduct();
                        System.out.println("");
                        break;

                    case 2:
                        System.out.println("Searching for a product...");
                        p.findProductById();
                        break;

                    case 3:
                        System.out.println("");
                        p.addPrescription();
                        System.out.println("Prescription added successfully!");
                        break;

                    case 4:
                        System.out.println("");
                        p.showPrescription();
                        break;

                    case 5:
                        System.out.println("next prescription in line...");
                        p.nextPrescription();
                        break;

                    case 6:
                        System.out.println("Processing and checking out the next prescription...");
                        p.checkNextPrescription();
                        break;

                    case 7:
                        System.out.println("Displaying all products currently in stock...");
                        p.displayAllProducts();
                        break;

                    case 8:
                        System.out.println("Exiting the system. Thank you for using Pharmacy Sales System!");
                        break;

                    default:
                        System.out.println("Invalid option! Please select a valid option from the menu.");
                }
            } catch (InputMismatchException e) {
                System.err.println("Invalid input. Please enter a number from the menu.");
                input.next(); 
            }
        } while (option != 8);

    }
}
