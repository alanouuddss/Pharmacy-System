
package ds_project;

public class Prescription  {

    private int  prescriptionID;
    private String patientName;
    private SinglyLinkedList<Product> products;

    public Prescription(int prescriptionID, String patientName, SinglyLinkedList<Product> products) {
        this.prescriptionID = prescriptionID;
        this.patientName = patientName;
        this.products = products;
    }
  
    public int getPrescriptionID() {
        return prescriptionID;
    }

    public void setPrescriptionID(int prescriptionID) {
        this.prescriptionID = prescriptionID;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public SinglyLinkedList<Product> getProducts() {
        return products;
    }

    public void setProducts(SinglyLinkedList<Product> products) {
        this.products = products;
    }
    public void addProduct(Product product) {
        products.addLast(product);
    }

   
    public double TotalAmount() {
        return products.totalAmount();
    }

    void displayPrescription() {
        System.out.println("Prescription ID: " + prescriptionID + ", Patient Name: " + patientName);

        products.displayProduct();
      
    }
    @Override
    public String toString() {
        return "Prescription{" + "prescriptionID=" + prescriptionID + ", patientName=" + patientName + ", products=" + products.viewList() + '}';
    }

}