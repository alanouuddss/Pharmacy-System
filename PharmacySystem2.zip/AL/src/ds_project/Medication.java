/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds_project;
public class Medication extends Product {

    private String Type;

    public Medication(String Type, int productID, double price, int quantity, String name, int Stock) {
        super(productID, price, quantity, name, Stock);
        this.Type = Type;
    }

    

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        this.Type = type;
    }

    @Override
    public String toString() {
        return super.toString() + "Type of Medication:  " + Type + "\n";
    }

}