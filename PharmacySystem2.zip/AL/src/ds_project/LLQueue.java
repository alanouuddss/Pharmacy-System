/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds_project;

public class LLQueue<E> {

    static class Node<E> {

        private E element;
        private Node<E> next;

        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }

        public E getElement() {
            return element;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> n) {
            next = n;
        }

        public void setelement(E element) {
            this.element = element;
        }
    }
    protected Node<E> front;
    protected Node<E> rear;
    protected int size;

    public LLQueue() { // constructor
        front = null;
        rear = null;
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public E first() { // returns (but does not remove) the first element
        if (isEmpty()) {
            return null;
        }
        return front.getElement();
    }

    public E last() { // returns (but does not remove) the last element
        if (isEmpty()) {
            return null;
        }
        return rear.getElement();
    }

    public void enqueue(E elem) {
        Node<E> newest = new Node<E>(elem, null);
        if (isEmpty()) {
            front = newest; // special case of a previously empty queue 
        } else {
            rear.setNext(newest); // add node at the tail of the list 
        }
        rear = newest; // update the reference to the tail node 
        size++;
    }

    public E dequeue() {
        if (isEmpty()) {
            return null;
        }
        E answer = front.getElement();
        front = front.getNext();
        size--;
        if (size == 0) {
            rear = null; // the queue is now empty
        }
        return answer;
    }

    public void Display() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        int s = size();

        for (int i = 0; i < s; i++) {
            E ele = dequeue();
            System.out.println(ele);

            enqueue(ele);
        }

    }

    public Prescription findPrescriptionById(int id) {
        int s = size();
        Prescription foundPrescription = null;

        for (int i = 0; i < s; i++) {
            Prescription ele = (Prescription) dequeue();
            if (((Prescription) ele).getPrescriptionID() == id) {
                foundPrescription = ele;
            }
            enqueue((E) ele);
        }
        return foundPrescription;
    }

    public void showNextPrescription() {
        if (isEmpty()) {
            System.out.println("No patients are currently waiting in the queue.");
        } else {
            Prescription upcoming = (Prescription) first();
            System.out.println("Next patient in line: '" + upcoming.getPatientName() + "'");
        }
    }

    public void processAndRemoveNextPrescription() {
        if (isEmpty()) {
            System.out.println("No prescriptions available for processing.");
        } else {
            Prescription toProcess = (Prescription) dequeue();
            System.out.println("Processing the order for: '" + toProcess.getPatientName() + "'");
            System.out.println("Details: " + toProcess);
            System.out.println("The prescription queue has been updated successfully.");
        }

    }

}
/*public boolean contains(E key) {
        
        Node<E> current = front;
        while (current != null) {
            if (current.equals(key)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }*/
