/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ds_project;

public class Other extends Product {

    private String item;

    @Override
    public String toString() {
        return super.toString()+ "Other{" + "item=" + item + '}';
    }


    public Other(String item, int productID, double price, int quantity, String name, int Stock) {
        super(productID, price, quantity, name, Stock);
        this.item = item;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

}
    

   