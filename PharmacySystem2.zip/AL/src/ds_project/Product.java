    
package ds_project;


public abstract class Product {

   
    private int productID;
    private double price;
    private int quantity ;
    private String name;
    private int Stock;
   
    
    public Product(int productID, double price, int quantity, String name, int Stock) {
        this.productID = productID;
        this.price = price;
        this.quantity = quantity;
        this.name = name;
        this.Stock = Stock;
    }

   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProductID() {
        return productID;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
      
        if (this.quantity - quantity < 0) {
            System.out.println("quantity of product ");
        }
        this.quantity = quantity;
    }

    public boolean validQuantity(int quantity) {

        if (quantity < 0) {
            System.out.println("quantity of product is not valid ");
            return false;
        }
        this.quantity = quantity;
        return true;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }
       

    
    
public void displayProduct() {
        System.out.println("Product ID: " + productID + ", Price: " + price + ", quantity: " + quantity  + ", Name: " + name);
    }

    @Override
    public String toString() {
        return "Product{" + "productID=" + productID + ", price=" + price + ", quantity=" + quantity + ", name=" + name + '}';
    }
}