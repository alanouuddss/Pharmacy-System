package ds_project;

import java.util.Scanner;

import java.util.Scanner;

public class PharmacySystem {

    private SinglyLinkedList<Product> productsList = new SinglyLinkedList<Product>();
    private LLQueue<Prescription> prescriptionsList = new LLQueue<>();

    private String name;
    Scanner input = new Scanner(System.in);

    public PharmacySystem(String name) {
        this.name = name;
        PList();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addProduct() {
        System.out.print("Enter Product ID: ");
        int productID = input.nextInt();
        input.nextLine();

        System.out.print("Enter Product Name: ");
        String name = input.nextLine();
        System.out.print("Enter Quantity: ");
        int quantity = input.nextInt();
        System.out.print("Enter Price: ");
        double price = input.nextDouble();

        System.out.print("1. Medication\n2. Other\nSelect product type: ");
        int type = input.nextInt();

        Product product = null;
        if (type == 1) {
            System.out.print("Enter Medication type: ");
            String medication = input.next();
            product = new Medication(medication, productID, price, quantity, name, 90);
        } else if (type == 2) {
            System.out.print("Enter Other item: ");
            String other = input.next();
            product = new Other(other, productID, price, quantity, name, 90);
        } else {
            System.out.println("Invalid product type selected.");
            return;
        }

        productsList.addProduct(product);
        System.out.println("Product added successfully.");
    }

    public void findProductById() {
        System.out.println("Enter product ID: ");
        int id = input.nextInt();

        Product product = productsList.findProductById(id);

        if (product == null) {
            System.out.println("No product found with this ID.");
            return;
        }

        System.out.println("Product information: ");
        product.displayProduct();
    }

    public void PList() {
        //String brand, int productID, double price, int quantity, String name, int Stock
        //String Type, int productID, double price, int quantity, String name, int Stock
        Other product1 = new Other("make up", 1, 19.00, 50, "AA", 101);
        Other product2 = new Other("wipes", 2, 30.00, 70, "PP", 90);
        Other product3 = new Other("lea", 3, 12.00, 45, "LL", 80);
        Medication product4 = new Medication("vitamins", 4, 80.00, 100, "C", 90);
        Medication product5 = new Medication("pills", 5, 84.00, 90, "MM", 70);
        Medication product6 = new Medication("SSSSS", 6, 50.00, 60, "LL", 60);

        SinglyLinkedList<Product> List = new SinglyLinkedList<>();
        SinglyLinkedList<Product> List2 = new SinglyLinkedList<>();
        SinglyLinkedList<Product> List3 = new SinglyLinkedList<>();

        productsList.addLast(product1);
        productsList.addLast(product2);
        productsList.addLast(product3);
        productsList.addLast(product4);
        productsList.addLast(product5);
        productsList.addLast(product6);
List.addLast(product1);
List.addLast(product1);
List2.addLast(product2);
List2.addLast(product2);
List3.addLast(product3);
List3.addLast(product3);

        
        product1.setQuantity(product1.getQuantity() - 1);
        product2.setQuantity(product2.getQuantity() - 1);
        product3.setQuantity(product3.getQuantity() - 1);
        product4.setQuantity(product4.getQuantity() - 1);
        product5.setQuantity(product5.getQuantity() - 1);
        product6.setQuantity(product6.getQuantity() - 1);

        Prescription pr1 = new Prescription(111, "Anoud", List);
        Prescription pr2 = new Prescription(222, "Lama", List2);
        Prescription pr3 = new Prescription(333, "Khaled", List3);

        prescriptionsList.enqueue(pr1);
        prescriptionsList.enqueue(pr2);
        prescriptionsList.enqueue(pr3);
    }

    public void addPrescription() {
        System.out.println("products to add to the prescription: ");
        int size = input.nextInt();

        SinglyLinkedList<Product> productList = new SinglyLinkedList<>();

        for (int i = 0; i < size;) {
            System.out.println("Enter product ID: ");
            int id = input.nextInt();

            Product pr = productsList.findProductById(id);

            System.out.println("Product info: ");
            System.out.println(pr);
            if (pr != null) {
                System.out.println("Enter quantity: ");
                int quantity = input.nextInt();

                if (!pr.validQuantity(quantity)) {
                    System.out.println("The valid quantity available is: " + pr.getQuantity());
                    System.out.println("Try again.");
                    continue;
                }
                i++;
                pr.setQuantity(pr.getQuantity() - quantity);

                if (pr instanceof Medication) {
                    String s = ((Medication) pr).getType();
                    Product p = new Medication(s, pr.getProductID(), pr.getPrice(), quantity, pr.getName(), pr.getStock());
                    productList.addLast(p);
                } else if (pr instanceof Other) {
                    String brand = ((Other) pr).getItem();
                    Product p = new Other(brand, pr.getProductID(), pr.getPrice(), quantity, pr.getName(), pr.getStock());
                    productList.addLast(p);
                }
            } else {
                System.out.println("Invalid product ID. Please try again.");
            }
        }
        System.out.println("Enter Customer name: ");
        String name = input.next();

        System.out.println("Enter prescription ID: ");
        int prescriptionID = input.nextInt();

        Prescription pre = new Prescription(prescriptionID, name, productList);
        prescriptionsList.enqueue(pre);

        System.out.println("Prescription added successfully.");
        pre.displayPrescription();
        System.out.println("----------------------------------------------");
    }


public void showPrescription() {
        System.out.println("Enter prescription ID: ");
        int id = input.nextInt();

       
        
        if (prescriptionsList.findPrescriptionById(id)!= null) {
          prescriptionsList.findPrescriptionById(id).displayPrescription();
        } else {
            System.out.println("No prescription found with this ID.");
        }
    }

    public void nextPrescription() {
        prescriptionsList.showNextPrescription();
    }

    public void checkNextPrescription() {
        prescriptionsList.processAndRemoveNextPrescription();
    }

    public void displayAllProducts() {
        productsList.display();
    }
    public void Total(){
        productsList.totalAmount();
    }
}
